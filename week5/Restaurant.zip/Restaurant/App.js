import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet} from 'react-native';
import MenuScreen from './screens/MenuScreen';
import BaseScreen from './screens/BaseScreen';
import { SafeAreaProvider } from 'react-native-safe-area-context';



export default function App() {
  const [currentScreen, setCurrentScreen] = useState("base");

  function eventsScreenHandler(){
    setCurrentScreen("menu");

  }

  function baseScreenHandler(){
    setCurrentScreen("base");
  }


  let screen = <BaseScreen onNext={eventsScreenHandler}/>;

  if(currentScreen == "menu") {
    screen = <MenuScreen/>
  }
  return (
    <>
    <StatusBar style='light' />
    <SafeAreaProvider style={styles.container}>{screen}</SafeAreaProvider>
    </>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
