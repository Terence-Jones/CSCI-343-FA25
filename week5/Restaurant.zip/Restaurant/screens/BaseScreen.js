import { StyleSheet, Text, View, Image, Linking, Button } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Title from "../components/Title";

export default function BaseScreen(props) {
  //setting safe area sceen boundaries
  const insets = useSafeAreaInsets();
  return(<View
    style={[
      styles.rootContainer,
      {
        paddingTop: insets.top,
        paddingBottom: insets.bottom,
        paddingLeft: insets.left,
        paddingRight: insets.right,
      },
    ]}
  >
    <View style= {styles.titleContainer}>
      <Title>House of Blues</Title>
    </View>
    <View style={styles.imageContainer}>
      <Image style={styles.image} source={require("../assets/images/venue.jpg")}/>
    </View>
    <View style={styles.infoContainer}>
      <Text
      style={styles.infoText}
      onPress={() => Linking.openURL("tel:8432723000")}
      
      >
        phone number
      </Text>
      <Text
      style={styles.infoText}
      onPress={() => Linking.openURL("https://maps.app.goo.gl/CeqUNQx7vSqxrTMU9")}>
        460 hwy 17 S{"\n"}North Mytrle Beach, SC 29582
      </Text>

      <Text
      style={styles.infoText}
      onPress={()=>Linking.openURL("https://cookout.com/")}>
        www.Cookout.com
      </Text>
    </View>

    <View style={styles.buttonContainer}>
      <Button title="Menu" onPress={props.onNext}/>
    </View>
  </View>
  );
  
}

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    alignItems: "center",
    
  },
  titleContainer:{
    flex: 1,
    justifyContent: "center"
  },

  imageContainer:{
    flex: 4


  },
  image:{
    resizeMode: "cover",
    height: "100%",
    width: 380

  },
  infoContainer:{
    flex: 3,
    justifyContent: "center"
  },
  infoText:{
    fontSize: 30,
    textAlign: "center",
    padding: 7
  },
  buttonContainer:{
    flex: 1,
    justifyContent: "center",
    alignContent: "center",
    borderRadius: 40,
    width: 150
  }
});
