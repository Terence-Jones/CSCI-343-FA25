//import React, { useState } from "react";
//import { StyleSheet, Text, View, useState } from "react-native";
//import { useSafeAreaInsets } from "react-native-safe-area-context";
//import Title from "../components/Title";
import React, { useState } from "react";
import { FlatList, StyleSheet, Text, View, Button } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Title from "../components/Title";
import MenuItem from "../components/MenuItem";

export default function MenuScreen(props) {
  //setting safe area sceen boundaries
  const insets = useSafeAreaInsets();

  const [MenuItems, setMenuItems] = useState([
    {
      name: "Chicken script Snack",
      image: require("../assets/images/chicken.jpg"),
      date: "06/16/2024",
      id: 1,
    },
    {
      name: "Cajun Fries",
      image: require("../assets/images/cajun.jpg"),
      date: "12/12/2022",
      id: 2,
    },
    {
      name: "Bacon Ranch Rap",
      image: require("../assets/images/ranch.jpg"),
      date: "6/20/2020",
      id: 3,
    },
    {
      name: "Chili Dog",
      image: require("../assets/images/chili.jpg"),
      date: "02/12/1999",
      id: 4,
    },
    {
      name: "Onion Rings",
      image: require("../assets/images/onion.jpg"),
      date: "09/10/1818",
      id: 5,
    },
  ]);

  return (
    <View
      style={[
        styles.rootContainer,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: insets.left,
          paddingRight: insets.right,
        },
      ]}
    >
      <View style={styles.titleContainer}>
        <Title>Menu</Title>
      </View>

      <View style={styles.listContainer}>
        <FlatList
          data={MenuItems}
          keyExtractor={(item, index) => {
            return item.id;
          }}
          alwaysBounceVertical={false}
          showsVerticalScrollIndicator={false}
          renderItem={(itemData) => {
            return (
              <MenuItem
                name={itemData.item.name}
                image={itemData.item.image}
                date={itemData.item.date}
              />
            );
          }}
        />
      </View>
      <View style={styles.buttonContainer}>
            <Button title="Main Menu" onPress={props.onNext}/>
            
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    alignItems: "center",
  },
  titleContainer: {
    flex: 1,
    justifyContent: "center",
  },
  listContainer:{
    flex: 7,
    width: 380
  },
  buttonContainer:{
    flex: 1,
    justifyContent: "center",
    alignContent: "center",
    borderRadius: 40,
    width: 150
  }
});
